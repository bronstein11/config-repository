package com.example.locacao.locacaoms;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LocacaoMsApplication {

	public static void main(String[] args) {
		SpringApplication.run(LocacaoMsApplication.class, args);
	}

}
