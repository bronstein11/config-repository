package com.example.locacao.locacaoms;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LocacaoMsApplicationTests {

	@Test
	void contextLoads() {
	}

}
