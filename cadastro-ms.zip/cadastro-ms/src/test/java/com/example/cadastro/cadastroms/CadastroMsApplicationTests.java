package com.example.cadastro.cadastroms;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CadastroMsApplicationTests {

	@Test
	void contextLoads() {
	}

}
