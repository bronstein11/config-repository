package com.example.cadastro.cadastroms;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CadastroMsApplication {

	public static void main(String[] args) {
		SpringApplication.run(CadastroMsApplication.class, args);
	}

}
